
/* =========================
   ESTADO GLOBAL
========================= */
let saldo = 0;
let receitas = 0;
let despesas = 0;
let transacoes = [];

let pieChart;
let lineChart;

/* =========================
   INICIALIZAÇÃO
========================= */
window.onload = function () {

  showLogin();

  // garante modal fechado
  const modal = document.getElementById("modal");
  if (modal) modal.style.display = "none";

  const charts = document.querySelector(".charts");
  if (charts) charts.classList.add("hidden");
};

/* =========================
   LOGIN / CADASTRO
========================= */
function login() {
  document.getElementById("loginPage").style.display = "none";
  document.getElementById("appPage").style.display = "block";

  showPage("dashboard");
}

function cadastrar() {
  const senha = document.getElementById("cadSenha").value;

  if (senha.length < 8) {
    alert("Senha deve ter no mínimo 8 caracteres");
    return;
  }

  showLogin();
}

function showCadastro() {
  document.getElementById("loginPage").style.display = "none";
  document.getElementById("cadastroPage").style.display = "flex";
}

function showLogin() {
  document.getElementById("cadastroPage").style.display = "none";
  document.getElementById("loginPage").style.display = "flex";
}

/* =========================
   NAVEGAÇÃO
========================= */
function showPage(pageId) {

  document.querySelectorAll(".page").forEach(p => {
    p.style.display = "none";
  });

  const target = document.getElementById(pageId);
  if (target) target.style.display = "block";
}

/* =========================
   MODAL
   🔵 COM COR DINÂMICA
========================= */
function openModal(tipo = "receita") {

  const modal = document.getElementById("modal");
  const content = document.querySelector(".modal-content");

  modal.style.display = "flex";

  content.classList.remove("receita", "despesa");
  content.classList.add(tipo);
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
}

/* =========================
   ADICIONAR TRANSAÇÃO
========================= */
function addTransacao() {

  const tipo = document.getElementById("tipo").value;
  const valor = parseFloat(document.getElementById("valor").value);
  const categoria = document.getElementById("categoria").value;

  if (!valor || valor <= 0) {
    alert("Digite um valor válido");
    return;
  }

  transacoes.push({ tipo, valor, categoria });

  if (tipo === "receita") {
    receitas += valor;
    saldo += valor;
    alert("Receita adicionada com sucesso!");
  } else {
    despesas += valor;
    saldo -= valor;
    alert("Despesa adicionada com sucesso!");
  }

  atualizar();
  atualizarLista();
  atualizarGraficos();

  closeModal();

  document.getElementById("valor").value = "";
  document.getElementById("categoria").value = "";
}

/* =========================
   ATUALIZAR DASHBOARD
========================= */
function atualizar() {

  document.getElementById("saldo").innerText = `R$ ${saldo.toFixed(2)}`;
  document.getElementById("receitas").innerText = `R$ ${receitas.toFixed(2)}`;
  document.getElementById("despesas").innerText = `R$ ${despesas.toFixed(2)}`;
}

/* =========================
   LISTA SEQUENCIAL
========================= */
function atualizarLista() {

  const container = document.getElementById("listaTransacoes");

  container.innerHTML = "";

  transacoes.forEach((t, index) => {

    const item = document.createElement("div");

    item.classList.add("item");
    item.classList.add(t.tipo); // receita ou despesa

    item.innerHTML = `
      <span>${index + 1}. ${t.categoria}</span>
      <strong>R$ ${t.valor.toFixed(2)}</strong>
    `;

    container.appendChild(item);
  });
}

/* =========================
   GRÁFICOS CONDICIONAIS
========================= */
function atualizarGraficos() {

  const charts = document.querySelector(".charts");

  // 🔵 se não tem dados, esconde gráficos
  if (receitas === 0 && despesas === 0) {

    charts.classList.add("hidden");
    return;
  }

  charts.classList.remove("hidden");

  if (pieChart) pieChart.destroy();
  if (lineChart) lineChart.destroy();

  /* 🔵 GRÁFICO DE SETORES */
  pieChart = new Chart(document.getElementById("chartPie"), {
    type: "doughnut",
    data: {
      labels: ["Receitas", "Despesas"],
      datasets: [{
        data: [receitas, despesas],
        backgroundColor: ["#2563eb", "#ef4444"]
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });

  /* 🔵 GRÁFICO DE LINHA */
  lineChart = new Chart(document.getElementById("chartLine"), {
    type: "line",
    data: {
      labels: transacoes.map((_, i) => i + 1),
      datasets: [{
        label: "Fluxo financeiro",
        data: transacoes.map(t =>
          t.tipo === "receita" ? t.valor : -t.valor
        ),
        borderColor: "#2563eb",
        tension: 0.3,
        fill: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false
    }
  });
}

/* =========================
   ASSINATURA
========================= */
function selectPlano(plano) {
  alert("Plano gratuito ativado!");
}

function goPagamento() {
  showPage("pagamento");
}

function pagar(tipo) {
  document.getElementById("status").innerText =
    "Pagamento realizado via " + tipo;
}

/* =========================
   LOGOUT
========================= */
function logout() {
  document.getElementById("appPage").style.display = "none";
  document.getElementById("loginPage").style.display = "flex";
}